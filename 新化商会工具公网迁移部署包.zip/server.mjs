import http from 'node:http';
import {readFile,writeFile,readdir,mkdir,stat,rename} from 'node:fs/promises';
import path from 'node:path';
import app from './app.mjs';
const root=path.resolve(process.env.DATA_DIR||'./data');
const port=Number(process.env.PORT||3000);
if(!process.env.ADMIN_PASSWORD||!process.env.EVENT_CODE){throw Error('请配置 ADMIN_PASSWORD 和 EVENT_CODE 环境变量');}
if(process.env.ADMIN_PASSWORD.length<14)throw Error('管理密码至少14个字符');
const resolveKey=k=>{const p=path.resolve(root,k);if(!p.startsWith(root+path.sep))throw Error('Invalid storage key');return p};
const bucket={
 async head(k){try{await stat(resolveKey(k));return {key:k}}catch(e){if(e.code==='ENOENT')return null;throw e}},
 async put(k,v){const f=resolveKey(k);await mkdir(path.dirname(f),{recursive:true});const temp=f+'.'+crypto.randomUUID()+'.tmp';await writeFile(temp,v,{mode:0o600});await rename(temp,f)},
 async get(k){try{const raw=await readFile(resolveKey(k),'utf8');return {json:async()=>JSON.parse(raw)}}catch(e){if(e.code==='ENOENT')return null;throw e}},
 async list({prefix=''}){const folder=resolveKey(prefix);try{const names=await readdir(folder);return {objects:names.filter(n=>n.endsWith('.json')).map(n=>({key:prefix+n})),truncated:false}}catch(e){if(e.code==='ENOENT')return {objects:[],truncated:false};throw e}}
};
const env={BUCKET:bucket,ADMIN_PASSWORD:process.env.ADMIN_PASSWORD,EVENT_CODE:process.env.EVENT_CODE};
await mkdir(root,{recursive:true});
const server=http.createServer(async(req,res)=>{
 try{
  let size=0,chunks=[];for await(const c of req){size+=c.length;if(size>20000){res.writeHead(413);res.end('请求内容过长');return}chunks.push(c)}
  const proto=process.env.PUBLIC_ORIGIN?new URL(process.env.PUBLIC_ORIGIN).protocol.slice(0,-1):'http';
  const origin=process.env.PUBLIC_ORIGIN||proto+'://'+req.headers.host;
  const request=new Request(origin+req.url,{method:req.method,headers:req.headers,...(['GET','HEAD'].includes(req.method)?{}:{body:Buffer.concat(chunks)})});
  const result=await app.fetch(request,env);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));
 }catch(e){console.error('Request failed:',e.message);res.writeHead(500,{'content-type':'text/plain;charset=utf-8'});res.end('服务暂不可用')}
});
server.listen(port,'0.0.0.0',()=>console.log('服务已启动，端口 '+port));
for(const sig of ['SIGINT','SIGTERM'])process.on(sig,()=>server.close(()=>process.exit(0)));
